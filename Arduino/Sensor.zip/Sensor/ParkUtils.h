#ifndef PARKUTILS_H
#define PARKUTILS_H

uint16_t checksum(uint8_t* data, uint16_t length);

#endif